# TTN TTGO LoRa32 BLE BRIDGE

Simple sketch, using PlatformIO IDE, to use the TTGO LoRa32 board as a node for The Things Network and bridge data received from the BLE interface to TTN.

The code uses IBM LMIC version for Arduino, but not streamlined for low memory devices.

For more information goto:  https://primalcortex.wordpress.com/2017/12/06/simple-ble-bridge-to-ttn-lora-using-the-ttgo-esp32-lora32-board/
