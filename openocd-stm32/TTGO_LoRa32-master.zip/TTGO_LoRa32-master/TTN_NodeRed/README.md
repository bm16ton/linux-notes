# Node-Red sample flow

Use this flow just for testing, since sending downlink data for each uplink might break the TTN user agreement.

This flow receives data sent from the nodes, calculates the recived RSSI and SNR, and sends it back to the node where it is displayed
on the OLED screen.


