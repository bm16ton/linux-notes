# TTN TTGO LoRa32 

Simple sketch, using PlatformIO IDE, to use the TTGO LoRa32 board as a node for The Things Network.

The code uses IBM LMIC version for Arduino, but not streamlined for low memory devices.

For more information goto:  https://wp.me/p8SNr-sR  -> Wordpress blog
