/* fbc-int API: array descriptor internals */

#include "fb.h"

FBCALL FBARRAY *fb_ArrayGetDesc( FBARRAY *array )
{
	return array;
}
