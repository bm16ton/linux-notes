/* view print update (console, no gfx) */

#include "../fb.h"
#include "fb_private_console.h"

void fb_ConsoleViewUpdate( void )
{
	fb_hUpdateConsoleWindow( );
}
