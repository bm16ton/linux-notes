/* console multikey() */

#include "../fb.h"

int fb_ConsoleMultikey( int scancode )
{
	fb_ErrorSetNum( FB_RTERROR_ILLEGALFUNCTIONCALL );
	return FB_FALSE;
}
