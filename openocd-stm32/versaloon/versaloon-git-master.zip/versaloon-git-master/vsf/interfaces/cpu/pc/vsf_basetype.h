
#ifndef __VSF_BASETYPE_H_INCLUDED__
#define __VSF_BASETYPE_H_INCLUDED__

// define the most efficient atom integer
typedef int vsf_int_t;

#endif	// __VSF_BASETYPE_H_INCLUDED__
