#define IS_MINGW	1
#define IS_WIN32	1

#define VERSION				"1.0"
#define PKGBLDDATE			__DATE__
#define RELSTR				"GCC:"
#define PKGBLDREV			"0000"
