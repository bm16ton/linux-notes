vsf_err_t vsprog_ui_init(void);
vsf_err_t vsprog_ui_set_title(char *title);
vsf_err_t vsprog_ui_set_task(char *task);
vsf_err_t vsprog_ui_set_progress(uint8_t percentage);
vsf_err_t vsprog_ui_print(char *str);
