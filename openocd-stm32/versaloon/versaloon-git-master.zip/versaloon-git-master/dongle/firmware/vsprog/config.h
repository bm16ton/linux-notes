#define VERSION				"1.1"
#define PKGBLDDATE			__DATE__
#define RELSTR				"GCC:"
#define PKGBLDREV			"0000"
