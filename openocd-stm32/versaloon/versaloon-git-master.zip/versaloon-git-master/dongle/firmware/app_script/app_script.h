
extern struct vss_cmd_list_t app_cmd_list;
