#define VERSION				"1.0"
#define PKGBLDDATE			__DATE__
#define RELSTR				"GCC:"
#define PKGBLDREV			"0000"
