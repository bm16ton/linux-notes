~/ws1/stvp/STVP_CmdLine.exe -BoardName=ST-LINK -ProgMode=SWD -Device=STM32F103xB -erase -no_loop -FileProg=Versaloon_GCC-VS_Dual-0x0000.hex 
