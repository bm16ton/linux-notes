vsf_err_t stm32_clko_init(uint8_t index);
vsf_err_t stm32_clko_fini(uint8_t index);
vsf_err_t stm32_clko_config(uint8_t index, uint32_t kHz);
vsf_err_t stm32_clko_enable(uint8_t index);
vsf_err_t stm32_clko_disable(uint8_t index);
