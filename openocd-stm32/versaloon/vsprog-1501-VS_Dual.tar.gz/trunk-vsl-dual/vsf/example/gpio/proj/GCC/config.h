#ifndef __CONFIG_H_INCLUDED__
#define __CONFIG_H_INCLUDED__

#define IS_WIN32			1

#define DEFAULT_INTERFACES	versaloon_interfaces
#define IFS_CFG_NO_BUFFER

#endif
