#include "port.h"
#include "app_cfg.h"
#include "app_type.h"
#include "app_io.h"
#include "app_err.h"
#include "app_log.h"

#define USBTOXXX_CFG_MAX_PENDING_NUMBER				4096
#define USBTOXXX_CFG_CMD_START						0x20
