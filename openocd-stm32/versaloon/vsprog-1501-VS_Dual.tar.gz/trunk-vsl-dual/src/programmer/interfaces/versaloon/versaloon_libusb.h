#ifndef __VERSALOON_LIBUSB_H_INCLLUDED__
#define __VERSALOON_LIBUSB_H_INCLUDED__

extern struct interfaces_comm_t versaloon_usb_comm;

#endif	// __VERSALOON_LIBUSB_H_INCLUDED__
