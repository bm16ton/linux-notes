#!/bin/bash

set -e
cd /etc/udev/rules.d
rm -f 49-stlinkv1.rules
rm -f 49-stlinkv2-1.rules
rm -f 49-stlinkv2.rules
rm -f 49-stlinkv3.rules
