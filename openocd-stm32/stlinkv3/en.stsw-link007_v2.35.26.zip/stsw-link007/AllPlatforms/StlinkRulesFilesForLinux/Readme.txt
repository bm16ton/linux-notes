Files to copy in /etc/udev/rules.d/ on Ubuntu ("sudo cp *.* /etc/udev/rules.d").

Note that a file is provided for ST-Link/V1 (idProduct=3744) despite most toolsets do
not support it.