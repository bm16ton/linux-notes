Copy .FLM files to Keil_install_dir\ARM\Flash.

Folder S29AL016J contains source code for loader. If rebuid is needed, copy directory
S29AL016J to Keil_install_dir\ARM\Flash and build it from there. Standard license
for Keil is required. Lite version will not build and get linker errors.